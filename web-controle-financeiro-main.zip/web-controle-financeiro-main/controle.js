const form = document.querySelector("#form");  //^^ para pegar um elemento no formulario no index por id
//const form = document.getElementById("form"); // outra maneira de pegar por id
//const significa que não ira mudar boas praticas

const descTransacaoInput = document.querySelector("#descricao");//selecionando o local de onde vem no html
const valorTransacaoInput = document.querySelector("#montante");//selecionando o local de onde vem no html
const balancoH1 = document.querySelector("#balanco"); //selecionando o local de onde vem no html


// para buscar o submit com uma função em especifico no caso do botao enviar
form.addEventListener("submit", (event) =>{
    event.preventDefault(); //para funcionar o evento normal do butao de enviar pra cá localmente.


    //alert(event); //mensagem para mostrar o que aconteceu.

    const descrTransacao = descTransacaoInput.value.trim(); //pegando os valores dos campos sem espaços em branco nas laterais final com () pois o trim é metodo;
    const valorTransacao = valorTransacaoInput.value.trim(); //pegando os valores dos campos sem espaços em branco nas laterais final com () pois o trim é metodo;

    //alert(descrTransacao + (" - ") + valorTransacao); //Mostrando os valores buscados acima, de forma concatenada.

    
    if (descrTransacao == "" || valorTransacao == "" ){ //if para informar ao usuario quando não tiver nada.
        alert("Informe os dados da transação!");
        return; // para informar q o metodo morre aqui.
    }

    //para capturar e mostrar e adicionar.

    const idTransacao = parseInt(Math.random() * 1000); //id aleatorio para nao dar erro.
    
    const transacao = { //criando um objeto para armazenar as variaveis 
        id: idTransacao, // para buscar o ID aleatorio
        descricao: descrTransacao , //busca a descricao digitada
        valor: parseFloat(valorTransacao), //busca o valor digitado
    };


    somaAoSaldo(transacao);// chamando uma função para somar





    descTransacaoInput.value = ""; //na caixa de digitação para limpar depois de feito tudo.
    valorTransacaoInput.value = ""; //na caixa de digitação para limpar depois de feito tudo.
});

function somaAoSaldo(transacao){ //criando a função para somar recebendo a variavel

    //const valor = transacao.valor; // buscando o valor digitado no campo valor.

    //pegando o html balanco retirando o sifrão e somando e atualizando.
    let total = balancoH1.innerHTML.replace("R$", ""); //pegando o que ta dentro da tag html e passando para o total, e com o replace tirando o sifrão, porém esta como string
    total = parseFloat(total);  //passando de string para ponto flutuante



    total = total + transacao.valor; // somando o total ao valor ou total+=


    //devolvendo o valor pro html
    balancoH1.innerHTML = `R$${total.toFixed(2)}`; //para retornar o valor feito com crase na tecla do agudo e o simbulo de cash para indicar ser uma variavel, fixed 2 para deixar apenas 2 casas decimais.

}