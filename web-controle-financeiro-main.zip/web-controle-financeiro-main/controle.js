const form = document.querySelector("#form");  //^^ para pegar um elemento no formulario no index por id
//const form = document.getElementById("form"); // outra maneira de pegar por id
//const significa que não ira mudar boas praticas


//variaveis globais
const descTransacaoInput = document.querySelector("#descricao");//selecionando o local de onde vem no html
const valorTransacaoInput = document.querySelector("#montante");//selecionando o local de onde vem no html
const balancoH1 = document.querySelector("#balanco"); //selecionando o local de onde vem no html
const receitasP = document.querySelector("#din-positivo");
const despesasP = document.querySelector("#din-negativo");
const transacoesUl = document.querySelector("#transacoes");


//api para salvar as informações do sistema. // pode ser feito depois do restante a baixo desta função
let transacoesSalvas = JSON.parse(localStorage.getItem("transacoes")); // para colocar no webstorage, o parse para não haver mudança de dados.
if (transacoesSalvas == null ){//para que caso não tenha nada confirmar que nao tera nada
 transacoesSalvas = []; //limpando o local de salvamento
}

// para buscar o submit com uma função em especifico no caso do botao enviar
form.addEventListener("submit", (event) =>{
    event.preventDefault(); //para funcionar o evento normal do butao de enviar pra cá localmente.


    //alert(event); //mensagem para mostrar o que aconteceu.

    const descrTransacao = descTransacaoInput.value.trim(); //pegando os valores dos campos sem espaços em branco nas laterais final com () pois o trim é metodo;
    const valorTransacao = valorTransacaoInput.value.trim(); //pegando os valores dos campos sem espaços em branco nas laterais final com () pois o trim é metodo;

    //alert(descrTransacao + (" - ") + valorTransacao); //Mostrando os valores buscados acima, de forma concatenada.

    
    if (descrTransacao == "" || valorTransacao == "" ){ //if para informar ao usuario quando não tiver nada.
        alert("Informe os dados da transação!");
        return; // para informar q o metodo morre aqui.
    }

    //para capturar e mostrar e adicionar.

    const idTransacao = parseInt(Math.random() * 1000); //id aleatorio para nao dar erro.
    
    //JSON
    const transacao = { //criando um objeto para armazenar as variaveis 
        id: idTransacao, // para buscar o ID aleatorio
        descricao: descrTransacao , //busca a descricao digitada
        valor: parseFloat(valorTransacao), //busca o valor digitado
    };

    //Armazenamento
    transacoesSalvas.push(transacao); //transacoes salvas recebe atributos para utilizar
    localStorage.setItem("transacoes", JSON.stringify(transacoesSalvas)) //enviando para o local storage, enviando no formato json para não haver mudança de dados;


    //funções
    somaAoSaldo(transacao);// chamando uma função para somar
    somaReceitaOuDespesa(transacao); //cahama a função que faz funcionar a receita ou despesa
    addTransacaoAoDOM(transacao);




    descTransacaoInput.value = ""; //na caixa de digitação para limpar depois de feito tudo.
    valorTransacaoInput.value = ""; //na caixa de digitação para limpar depois de feito tudo.
});


//para mostrar o valor
function somaAoSaldo(transacao){ //criando a função para somar recebendo a variavel

    //const valor = transacao.valor; // buscando o valor digitado no campo valor.

    //pegando o html balanco retirando o sifrão e somando e atualizando.
    let total = balancoH1.innerHTML.replace("R$", ""); //pegando o que ta dentro da tag html e passando para o total, e com o replace tirando o sifrão, porém esta como string
    total = parseFloat(total);  //passando de string para ponto flutuante



    total = total + transacao.valor; // somando o total ao valor ou total+=


    //devolvendo o valor pro html
    balancoH1.innerHTML = `R$${total.toFixed(2)}`; //para retornar o valor feito com crase na tecla do agudo e o simbulo de cash para indicar ser uma variavel, fixed 2 para deixar apenas 2 casas decimais.

}

//para adicionar despesa e receita.
function somaReceitaOuDespesa(transacao){
    const elemento = transacao.valor > 0 ? receitasP : despesasP; //recebe o din positivo e negativo e ve se é receita ou despesa, ta usando o comparador ternario.
    // alert(elemento.innerHTML); // para testar e ver se vai funcionar.
    const substituir = transacao.valor > 0 ? "+ R$" : "- R$"; // comparação para dar o replace nos campos apropriados e com isso trocar no html
    let valorAtual = elemento.innerHTML.replace(substituir, "");
    // alert(valorAtual); //testando o valor atual
    valorAtual = parseFloat(valorAtual); // trocando o tipo do valor de string para float.

    valorAtual = valorAtual+ Math.abs(transacao.valor); //para adicionar ao campo. usando a Maths.abs para deixar sempre positivo o valor

    elemento.innerHTML = `${substituir} ${valorAtual}`; //retornando o elemento da forma correta com template string semelhante ao printf

}

//para mostrar a transação
function addTransacaoAoDOM(transacao){
    const operador = transacao.valor > 0 ? "" : "-"; 

    //mexendo no li
    const classe = transacao.valor > 0 ? "positivo" : "negativo"; //pegando o valor e diferenciando se é posivito ou negativo.
    
    //para recriar o li
    const li = document.createElement("li");//criou a li
    li.classList.add(classe);//setou a classe
    li.innerHTML = `${transacao.descricao} <span>${operador} ${Math.abs(transacao.valor)}
    </span><button class="delete-btn">X</button></li>`;

    //para puxar as li uma a uma digitada pelo usuario
    transacoesUl.append(li);

}

//retornar as coisas do banco carregadas antes
function carregarDados(){
    transacoesUl.innerHTML = ""; //PARA Limpar a LI para nao duplicar as outras
    balancoH1.innerHTML = "R$0.00";// limpar o balanco  
    receitasP.innerHTML = "+ R$0.00"; //limpar receita  
    despesasP.innerHTML = "- R$0.00"; //limpar despesa

    for(let i = 0; i < transacoesSalvas.length; i++){
    const transacao = transacoesSalvas[i];
    somaAoSaldo(transacao);
    somaReceitaOuDespesa(transacao); 
    addTransacaoAoDOM(transacao);
    }

}

carregarDados();